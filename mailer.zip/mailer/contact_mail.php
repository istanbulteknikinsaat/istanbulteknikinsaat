﻿<?php
include_once('contact_server.php');
//include_once('baglan.php');
if(!isset($_POST['satid']) || empty($_POST['kabul']) || !isset($_POST['teslimtarih'])) {
    	echo"<script>alert('Lütfen zorunlu alanları doldurunuz.');</script>";
}
else{
	//iconv_set_encoding("internal_encoding", "UTF-8");
	$to ="ilkerrakk52@gmail.com";
	$subject= $_POST['satid'] . "Sipariş Kabul Formu";
	$message="";
	
	$message .= "<html>
	<head>
	  <title>İstanbulTeknik.com Web Sitesinden mesaj var</title>
	</head>
	<body>
	  <p><b>Mesajı Gönderen:</b> ".$_POST['satid']."</p>
	  <p><b>Firma:</b> ".$_POST['kabul']."</p>
	  <p><b>Görev:</b> ".$_POST['stok']."</p>
	  <p><b>Telefon :</b> ".$_POST['teslimtarih']."</p>

	</body>
	</html>";
	
	$headers = "MIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\n";
	$headers .= "Reply-To: Auto generated mail. Please not replay.\r\n";
	$messages = $message;
	$mailsend = new EmailSender($to, "", $messages, $subject);
	$company = $mailsend->sendnow();
	if(isset($company)) {
		date_default_timezone_set('Etc/GMT-3');//Türkiye saatine göre ayarlandı.
        $zaman = date('Y-m-d H:i:s',time());
		//$contact=mysql_query("INSERT INTO application (name_surname,email,message,date_application) VALUES('".mysql_real_escape_string($_POST["name_surname"])."','".mysql_real_escape_string($_POST['email'])."', '".mysql_real_escape_string($_POST['message'])."','$zaman')");

        	echo"<script>alert('Mesajınız başarıyla teslim edildi.');</script>";
			echo "<script>window.location='tedarikci.php?satid=77';</script>";
	}
	else {
        	echo"<script>alert('Lütfen tekrar deneyiniz.');</script>";
	}
}
?>