<?php
if($_SERVER['SERVER_NAME']=='localhost')
{
	$host='localhost';
	$kullanici='root';
	$sifre='';
	define('DOMAIN', 'https://istanbulteknik.com');
}
else
{
	$host='localhost';
	$kullanici='istanbulteknik';
	$sifre='4{@"w4xJJPN{*]6G';
	define('DOMAIN', 'https://istanbulteknik.com/');
}
$baglanti = mysql_connect($host, $kullanici, $sifre) or die (mysql_error());
$veritabani= mysql_select_db("istanbulteknik", $baglanti) or die (mysql_error());
mysql_unbuffered_query('SET NAMES utf8');
define('PANEL', DOMAIN.'/admin');
define('PANEL_TITLE', 'İstanbul Teknik');
session_start();
